package com.klef.jfsd.exam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.exam.model.Customer;
import com.klef.jfsd.exam.repository.CustomerRepository;

@Service
public class ServiceImpl implements CustomerService{
	@Autowired
    private CustomerRepository customerRepository;
	@Override
	public String updateCustomerDetails(int id, String name, String address) {
        Customer customer = customerRepository.findById(id).orElse(null);
        if (customer != null) {
            customer.setName(name);
            customer.setAddress(address);
            customerRepository.save(customer);
            return "Customer updated successfully";
        } else {
            return "Customer with ID " + id + " not found.";
        }
}
}