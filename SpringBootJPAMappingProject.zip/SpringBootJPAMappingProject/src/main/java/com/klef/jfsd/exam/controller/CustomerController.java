package com.klef.jfsd.exam.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.klef.jfsd.exam.model.Customer;
import com.klef.jfsd.exam.repository.CustomerRepository;
import com.klef.jfsd.exam.service.CustomerService;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CustomerService customerService;

    // Insert a record manually
    @PostMapping("/add")
    public String addCustomer(@RequestBody Customer customer) {
        customerRepository.save(customer);
        return "Customer added successfully";
    }

    // Update Customer Name and Address
    @PutMapping("/update")
    public String updateCustomer(@RequestParam int id, @RequestParam String name, @RequestParam String address) {
        return customerService.updateCustomerDetails(id, name, address);
    }
}
