package com.klef.jfsd.exam.service;


import com.klef.jfsd.exam.model.Customer;

public interface CustomerService {
    String updateCustomerDetails(int id, String name, String address);
}
